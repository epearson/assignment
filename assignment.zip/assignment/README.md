# Assignment
## General Notes

Naming Conventions: 

Tried to stick with what is generally popular with each programming language with the primary goal of readability.

Code Commenting Strategy: 

I try to make the code itself readable and add comments as needed to improve readability. Often answering "Why?" rather than "What?" I'm doing with the code. 

## Project Summary

* rest-to-jms: Part 1 of the project (Node.js)
* JmsToDb: Part 2 of the project (C# .NET Core)